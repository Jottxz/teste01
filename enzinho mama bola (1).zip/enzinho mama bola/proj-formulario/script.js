document.getElementById("contactform").addEventListener("submit",function(event)
{
    event.preventDefault();
    const name = document.getElementById("name").ariaValueMax.
}
if (!ValidateEmail(email)) {
    errorMessage
}
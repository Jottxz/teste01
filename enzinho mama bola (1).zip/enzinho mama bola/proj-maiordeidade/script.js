function checkEligibility() {
        // Obtendo o ano corrente
    const currentYear = new Date().getFullYear();
 
    //Obtendo o valor do formulario
    const birthYear = parseInt(document.getElementById('birth-year').value);
    const name = document.getElementById('name').value;
 
    // Calculando a idade
    const age = currentYear - birthYear;
 
    // Selecionando o elemento para mostrar a mensagem
    const resultElement = document.getElementById('result');
 
    //Verificando a faixa etaria e definindo a mensagem
    if (age >= 18) {
        resultElement.textContent = "Aluno(a) maior de idade, pode continuar com o cadastro.";
    } else if (age >= 14 && age < 18) {
        resultElement.textContent = "Aluno(a) deve solicitar a assinatura dos pais ou responsaveis.";
    } else if (age < 14) {
        resultElement.textContent = "So serao aceitos alunos(as) com 14 ou mais neste curso.";
    } else {
        resultElement.textContent = "Idade inválida";
    }
    }

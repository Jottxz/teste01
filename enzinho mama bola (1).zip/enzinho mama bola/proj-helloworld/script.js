function mensagem() {
    document.getElementById("message").textContent = "Pegadinho do malandro"
}